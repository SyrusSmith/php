<!DOCTYPE>
<html>
    <head>
        <title> Formulario </title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    </head>
    <body>
        <strong> Bienvenido... Ingrese al Sistema con su Nombre y Correo Electrónico </strong>
        <br>
        <a href="index.php">Volver al formulario</a>
    </body>
</html> 