<?php

echo "Muchas gracias por registrarte $nombre $apellido";

?>